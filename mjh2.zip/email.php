<?
   exec("python sendmail3.py")
?>
